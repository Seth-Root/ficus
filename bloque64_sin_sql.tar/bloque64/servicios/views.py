from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from servicios.models import Publicacion
from servicios.serializers import PublicacionSerializer


@api_view(['GET', 'POST'])
def publicacion_list(request, format=None):
    """
    List all publicaciones, or create a new publicacion.
    """
    if request.method == 'GET':
        publicaciones = Publicacion.objects.all()
        serializer = PublicacionSerializer(publicaciones, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = PublicacionSerializer(data=request.data)
        print serializer
        print serializer.is_valid()
        if serializer.is_valid():

            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def publicacion_detail(request, pk, format=None):
    """
    Retrieve, update or delete a publicacion instance.
    """
    try:
        publicacion = Publicacion.objects.get(pk=pk)
    except Publicacion.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = PublicacionSerializer(publicacion)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = PublicacionSerializer(publicacion, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        publicacion.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
